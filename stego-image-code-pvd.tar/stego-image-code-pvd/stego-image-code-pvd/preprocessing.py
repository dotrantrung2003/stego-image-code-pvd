from PIL import Image
import numpy as np
import sys

# image_path = "image.png"
image_path = sys.argv[1]
img = Image.open(image_path).convert("L")

print("Image name:", image_path)
width, height = img.size
print(f"Image size: {width} x {height} pixels")

gray_matrix = np.array(img)
np.savetxt("gray_matrix.txt", gray_matrix, fmt='%d')
print("Gray matrix has been saved in gray_matrix.txt")

gray_matrix = np.loadtxt("gray_matrix.txt", dtype=np.uint8)
gray_image = Image.fromarray(gray_matrix, mode='L')
gray_image.save("gray_image.png")
print("Gray image has been saved in gray_image.txt")



