from PIL import Image
import numpy as np
import sys

matrix_path = sys.argv[1] #new_gray_matrix
gray_matrix = np.loadtxt(matrix_path, dtype=np.int16)

gray_clipped = np.clip(gray_matrix, 0, 255)
gray_uint8 = gray_clipped.astype(np.uint8)

new_img = Image.fromarray(gray_uint8, mode='L')
new_image_path = "new_gray_image.png"
new_img.save(new_image_path)

print("Image name:", new_image_path)
width, height = new_img.size
print(f"Image size: {width} x {height} pixels")
print("New gray image has been saved in new_gray_image.txt")