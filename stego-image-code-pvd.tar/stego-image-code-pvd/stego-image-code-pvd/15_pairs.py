import numpy as np
import sys

matrix_path = sys.argv[1] #gray_matrix
gray_matrix = np.loadtxt(matrix_path, dtype=np.int16)

last_row = gray_matrix[-1]
with open("15_pairs.txt", "w") as f:
    for i in range(0, 30, 2):
        a, b = last_row[i], last_row[i + 1]
        f.write(f"{a} {b}\n")

print("The first 15 pairs of the last row have been saved in 15_pairs.txt")