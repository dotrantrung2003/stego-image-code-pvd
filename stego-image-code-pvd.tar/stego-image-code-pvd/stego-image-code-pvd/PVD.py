from PIL import Image
import numpy as np
import sys

pairs_path = sys.argv[1] #new_15_pairs
pairs = np.loadtxt(pairs_path, dtype=np.int16)
flat_values = pairs.flatten()

matrix_part = sys.argv[2] #gray_matrix
gray_matrix = np.loadtxt(matrix_part, dtype=np.int16)
height, width = gray_matrix.shape

gray_matrix[-1, 0:30] = flat_values

np.savetxt("new_gray_matrix.txt", gray_matrix, fmt="%d")
print("New gray matrix has been saved in new_gray_matrix.txt")


